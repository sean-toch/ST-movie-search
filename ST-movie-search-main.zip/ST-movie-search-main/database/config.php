<?php

return [
    "server_name" => "127.0.0.1",
    "username" => "root",
    "password" => "mariadb",
    "dbname" => "moviehouse"
];
