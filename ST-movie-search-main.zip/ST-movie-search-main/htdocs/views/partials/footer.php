<div class="footer">
    <h2>Last Logged In <?php echo $previous ?></h2>
</div>