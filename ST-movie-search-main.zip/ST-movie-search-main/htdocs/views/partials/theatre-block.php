<div class="theatre-item">
    <h2><?php echo $theatre['name'], " ";  ?></h2>
    <h3><?php echo $theatre['address']; ?></h3>
    <h2><?php echo theatre_link($theatre); ?></h2>
</div>