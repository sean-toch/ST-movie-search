export const state = { searchResults: [], nowPlayingList: [] };
